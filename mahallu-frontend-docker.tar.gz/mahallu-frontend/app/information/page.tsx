'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, User, Eye, Tag, ArrowRight, Search, Filter } from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import apiService from '@/lib/api';

interface NewsItem {
  id: number;
  title: string;
  content: string;
  excerpt?: string;
  image_url?: string;
  category: string;
  author_name?: string;
  published_date: string;
  view_count?: number;
  is_featured: boolean;
  status: 'published' | 'draft';
  created: string;
  modified: string;
}

export default function InformationPage() {
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [filteredNews, setFilteredNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [categories, setCategories] = useState<string[]>([]);

  useEffect(() => {
    fetchNews();
  }, []);

  useEffect(() => {
    filterNews();
  }, [newsItems, selectedCategory, searchTerm]);

  const fetchNews = async () => {
    try {
      setLoading(true);
      const response = await apiService.getNews();
      const news = response.data || response;
      setNewsItems(news);
      
      // Extract unique categories
      const uniqueCategories = [...new Set(news.map((item: NewsItem) => item.category))];
      setCategories(uniqueCategories as string[]);
    } catch (error) {
      console.error('Error fetching news:', error);
      // Use mock data for demo
      const mockNews = generateMockNews();
      setNewsItems(mockNews);
      const uniqueCategories = [...new Set(mockNews.map(item => item.category))];
      setCategories(uniqueCategories);
    } finally {
      setLoading(false);
    }
  };

  const filterNews = () => {
    let filtered = newsItems;

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(item => item.category === selectedCategory);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(item =>
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.content.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredNews(filtered);
  };

  const featuredNews = newsItems.filter(item => item.is_featured);
  const regularNews = filteredNews.filter(item => !item.is_featured);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900 text-white py-20 overflow-hidden">
        <div className="absolute inset-0 islamic-pattern opacity-10"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-emerald-900/50 to-transparent"></div>
        
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <h1 className="font-display text-5xl md:text-6xl font-bold mb-4">
              Community News & Updates
            </h1>
            <p className="text-xl text-emerald-100">
              Stay informed with the latest announcements, events, and updates from our mahallu
            </p>
          </motion.div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="bg-white border-b border-gray-200 sticky top-16 z-40 shadow-sm">
        <div className="container-custom py-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search news and announcements..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input pl-10 w-full"
              />
            </div>

            {/* Category Filter */}
            <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`btn whitespace-nowrap ${
                  selectedCategory === 'all'
                    ? 'btn-primary'
                    : 'btn-outline'
                }`}
              >
                All News
              </button>
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`btn whitespace-nowrap ${
                    selectedCategory === category
                      ? 'btn-primary'
                      : 'btn-outline'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Results count */}
          <div className="mt-4 text-sm text-gray-600">
            Showing <span className="font-semibold text-gray-900">{filteredNews.length}</span> {filteredNews.length === 1 ? 'article' : 'articles'}
          </div>
        </div>
      </section>

      {/* Featured News */}
      {featuredNews.length > 0 && selectedCategory === 'all' && !searchTerm && (
        <section className="bg-gradient-to-b from-white to-gray-50 py-12">
          <div className="container-custom">
            <h2 className="font-display text-3xl font-bold mb-8 text-gray-900">
              Featured Stories
            </h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              {featuredNews.slice(0, 2).map((item, index) => (
                <FeaturedNewsCard key={item.id} item={item} index={index} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Regular News Grid */}
      <section className="py-12">
        <div className="container-custom">
          {loading ? (
            <div className="flex justify-center py-12">
              <div className="spinner"></div>
            </div>
          ) : regularNews.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No news articles found.</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {regularNews.map((item, index) => (
                <NewsCard key={item.id} item={item} index={index} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

// Featured News Card Component
function FeaturedNewsCard({ item, index }: { item: NewsItem; index: number }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
    >
      <Link href={`/information/${item.id}`}>
        <div className="card overflow-hidden hover:shadow-2xl transition-all cursor-pointer h-full">
          {/* Image */}
          {item.image_url && (
            <div className="relative h-64 bg-gradient-to-br from-emerald-100 to-teal-100 overflow-hidden">
              <img
                src={item.image_url}
                alt={item.title}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute top-4 left-4">
                <span className="badge badge-warning">Featured</span>
              </div>
            </div>
          )}

          {/* Content */}
          <div className="p-6">
            <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
              <span className="badge badge-info">{item.category}</span>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {format(new Date(item.published_date), 'MMM dd, yyyy')}
              </div>
            </div>

            <h3 className="font-display text-2xl font-bold text-gray-900 mb-3 hover:text-emerald-600 transition-colors">
              {item.title}
            </h3>

            <p className="text-gray-600 mb-4 line-clamp-3">
              {item.excerpt || item.content.substring(0, 150) + '...'}
            </p>

            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              {item.author_name && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <User className="w-4 h-4" />
                  {item.author_name}
                </div>
              )}
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Eye className="w-4 h-4" />
                {item.view_count || 0} views
              </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.article>
  );
}

// Regular News Card Component
function NewsCard({ item, index }: { item: NewsItem; index: number }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <Link href={`/information/${item.id}`}>
        <div className="card overflow-hidden hover:shadow-xl transition-all cursor-pointer h-full flex flex-col">
          {/* Image */}
          {item.image_url && (
            <div className="relative h-48 bg-gradient-to-br from-emerald-100 to-teal-100 overflow-hidden">
              <img
                src={item.image_url}
                alt={item.title}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          )}

          {/* Content */}
          <div className="p-6 flex-1 flex flex-col">
            <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
              <span className="badge badge-info">{item.category}</span>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {format(new Date(item.published_date), 'MMM dd, yyyy')}
              </div>
            </div>

            <h3 className="font-display text-xl font-bold text-gray-900 mb-3 hover:text-emerald-600 transition-colors">
              {item.title}
            </h3>

            <p className="text-gray-600 mb-4 line-clamp-3 flex-1">
              {item.excerpt || item.content.substring(0, 120) + '...'}
            </p>

            <div className="flex items-center justify-between pt-4 border-t border-gray-100 mt-auto">
              {item.author_name && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <User className="w-4 h-4" />
                  {item.author_name}
                </div>
              )}
              <div className="flex items-center gap-2 text-emerald-600 font-medium">
                Read more
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.article>
  );
}

// Mock data generator
function generateMockNews(): NewsItem[] {
  const categories = ['Announcements', 'Events', 'Community', 'Programs', 'Updates'];
  const titles = [
    'Ramadan Programs 2026 Schedule Announced',
    'Annual Mahallu General Body Meeting',
    'New Educational Support Program Launched',
    'Community Health Camp This Weekend',
    'Mahallu Library Now Open to All Members',
    'Eid Celebration Plans Finalized',
    'Youth Development Workshop Registration Open',
    'Monthly Newsletter - January 2026',
  ];

  return Array.from({ length: 8 }, (_, i) => ({
    id: i + 1,
    title: titles[i] || `Community Update ${i + 1}`,
    content: `This is detailed content for news item ${i + 1}. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.`,
    excerpt: `A brief summary of the news article ${i + 1} that provides a quick overview of the content.`,
    image_url: i % 3 === 0 ? `https://picsum.photos/seed/${i}/800/600` : undefined,
    category: categories[i % categories.length],
    author_name: `Admin User ${i % 3 + 1}`,
    published_date: new Date(2026, 0, 20 - i).toISOString(),
    view_count: Math.floor(Math.random() * 500) + 50,
    is_featured: i < 2,
    status: 'published',
    created: new Date(2026, 0, 20 - i).toISOString(),
    modified: new Date(2026, 0, 20 - i).toISOString(),
  }));
}
