'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { Users, Home, Heart, TrendingUp, Shield, BookOpen } from 'lucide-react';
import StatsOverview from '@/components/StatsOverview';

export default function HomePage() {
  return (
    <div className="relative">
      {/* Hero Section with Islamic Pattern Background */}
      <section className="relative bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900 text-white overflow-hidden">
        <div className="absolute inset-0 islamic-pattern opacity-20"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-emerald-900/50 to-transparent"></div>
        
        <div className="container-custom relative z-10 py-24 md:py-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl"
          >
            <h1 className="font-display text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Mahallu Management
              <span className="block text-amber-300">Made Simple</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-emerald-100 leading-relaxed">
              A comprehensive digital platform for Kerala Muslim communities to manage families, 
              members, registrations, and community welfare programs efficiently.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/families" className="btn btn-secondary text-lg">
                Browse Families
              </Link>
              <Link href="/login" className="btn btn-outline text-lg border-white text-white hover:bg-white hover:text-emerald-900">
                Admin Login
              </Link>
            </div>
          </motion.div>

          {/* Decorative Elements */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="absolute right-0 top-1/2 -translate-y-1/2 w-96 h-96 bg-amber-400/10 rounded-full blur-3xl"
          ></motion.div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 bg-gradient-to-b from-gray-50 to-white">
        <div className="container-custom">
          <StatsOverview />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4 text-gray-900">
              Comprehensive Features
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Everything you need to manage your mahallu community effectively
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="card p-8 group hover:shadow-2xl"
              >
                <div className="w-14 h-14 bg-emerald-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-emerald-600 transition-colors">
                  <feature.icon className="w-7 h-7 text-emerald-700 group-hover:text-white transition-colors" />
                </div>
                <h3 className="font-display text-2xl font-semibold mb-3 text-gray-900">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-emerald-600 to-teal-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 islamic-pattern opacity-10"></div>
        <div className="container-custom relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
              Ready to Transform Your Mahallu?
            </h2>
            <p className="text-xl mb-8 text-emerald-100 max-w-2xl mx-auto">
              Join modern mahallu management with our comprehensive digital platform
            </p>
            <Link href="/login" className="btn btn-secondary text-lg inline-flex items-center gap-2">
              Access Admin Panel
              <Shield className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container-custom">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-display text-2xl font-bold text-white mb-4">
                Mahallu System
              </h3>
              <p className="text-gray-400">
                Modern digital platform for Kerala Muslim community management
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/families" className="hover:text-emerald-400 transition-colors">Families</Link></li>
                <li><Link href="/members" className="hover:text-emerald-400 transition-colors">Members</Link></li>
                <li><Link href="/registrations" className="hover:text-emerald-400 transition-colors">Registrations</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Admin</h4>
              <ul className="space-y-2">
                <li><Link href="/login" className="hover:text-emerald-400 transition-colors">Login</Link></li>
                <li>
                  <a 
                    href="https://services.mahallu.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-emerald-400 transition-colors"
                  >
                    Backend Dashboard
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
            <p>&copy; 2026 Mahallu Management System. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

const features = [
  {
    icon: Home,
    title: 'Family Management',
    description: 'Comprehensive family records with membership details, addresses, and household information.',
  },
  {
    icon: Users,
    title: 'Member Directory',
    description: 'Detailed member profiles with demographics, education, employment, and health information.',
  },
  {
    icon: Heart,
    title: 'Birth & Marriage Registry',
    description: 'Digital registration system for births and marriages with proper documentation.',
  },
  {
    icon: TrendingUp,
    title: 'Subscription Tracking',
    description: 'Monitor and manage family subscription payments and pending collections.',
  },
  {
    icon: Shield,
    title: 'Ward Management',
    description: 'Organize families by wards and panchayath divisions for better administration.',
  },
  {
    icon: BookOpen,
    title: 'Reports & Analytics',
    description: 'Generate comprehensive reports and insights about your community.',
  },
];
